--DROP TABLE warframe_release;
--DROP TABLE warframe_health;
--DROP TABLE warframe_shields;
--DROP TABLE warframe_energy;
--DROP TABLE warframe_armor;
--DROP TABLE warframe_speed;

CREATE TABLE warframe (
    wf_id int primary key,
    wf_name varchar(255) NOT NULL,
    wf_ranked varchar(255) NOT NULL
);
CREATE TABLE warframe_release (
    wf_release date,
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);
CREATE TABLE warframe_health (
    wf_health int,
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);

CREATE TABLE warframe_shields (
    wf_shields int,
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);

CREATE TABLE warframe_energy (
    wf_energy varchar(4),
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);

CREATE TABLE warframe_armor (
    wf_armor int,
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);

CREATE TABLE warframe_speed (
    wf_speed varchar(4),
    wf_id int,
    foreign key(wf_id) references warframe(wf_id) 
);


INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(1, 'Ash', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(2, 'Ash', 'ranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(3, 'Ash Prime', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(4, 'Ash Prime', 'ranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(5, 'Atlas', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(6, 'Atlas', 'ranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(7, 'Atlas Prime', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(8, 'Atlas Prime', 'ranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(9, 'Banshee', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(10, 'Banshee', 'ranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(11, 'Banshee Prime', 'unranked');
INSERT INTO warframe (wf_id, wf_name, wf_ranked) VALUES(12, 'Banshee Prime', 'ranked');

INSERT INTO warframe_release (wf_release, wf_id) VALUES('2012-10-25', 1);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2012-10-25', 2);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2015-07-07', 3);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2015-07-07', 4);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2015-10-01', 5);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2015-10-01', 6);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2019-10-01', 7);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2019-10-01', 8);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2013-03-18', 9);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2013-03-18', 10);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2017-02-28', 11);
INSERT INTO warframe_release (wf_release, wf_id) VALUES('2017-02-28', 12);

INSERT INTO warframe_health (wf_health, wf_id) VALUES(150, 1);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(450, 2);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(150, 3);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(450, 4);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(100, 5);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(300, 6);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(175, 7);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(525, 8);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(100, 9);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(300, 10);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(100, 11);
INSERT INTO warframe_health (wf_health, wf_id) VALUES(300, 12);

INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(100, 1);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(300, 2);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(125, 3);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(375, 4);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(100, 5);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(300, 6);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(150, 7);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(450, 8);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(100, 9);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(300, 10);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(100, 11);
INSERT INTO warframe_shields (wf_shields, wf_id) VALUES(300, 12);

INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('100', 1);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('150', 2);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('125', 3);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('375', 4);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('150', 5);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('225', 6);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('175', 7);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('262.5', 8);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('150', 9);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('225', 10);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('175', 11);
INSERT INTO warframe_energy (wf_energy, wf_id) VALUES('262.5', 12);

INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(100, 1);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(100, 2);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(175, 3);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(175, 4);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(450, 5);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(450, 6);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(475, 7);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(475, 8);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(100, 9);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(100, 10);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(125, 11);
INSERT INTO warframe_armor (wf_armor, wf_id) VALUES(125, 12);

INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.15', 1);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.15', 2);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.2', 3);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.2', 4);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('0.9', 5);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('0.9', 6);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1', 7);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1', 8);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.1', 9);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.1', 10);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.15', 11);
INSERT INTO warframe_speed (wf_speed, wf_id) VALUES('1.15', 12);



SELECT warframe.wf_id, warframe.wf_name, warframe.wf_ranked, warframe_release.wf_release, warframe_health.wf_health, warframe_shields.wf_shields, warframe_armor.wf_armor, warframe_speed.wf_speed
FROM warframe
INNER JOIN warframe_release
ON warframe.wf_id = warframe_release.wf_id
INNER JOIN warframe_health
ON warframe.wf_id = warframe_health.wf_id
INNER JOIN warframe_shields
ON warframe.wf_id = warframe_shields.wf_id
INNER JOIN warframe_energy
ON warframe.wf_id = warframe_energy.wf_id
INNER JOIN warframe_armor
ON warframe.wf_id = warframe_armor.wf_id
INNER JOIN warframe_speed
ON warframe.wf_id = warframe_speed.wf_id;

